package business;

/**
 * validates survey inputs
 * 
 * @author Joseph
 *
 */
public class ValidateSurvey {

	String n;

	/**
	 * passes in input and determines if valid
	 * 
	 * @param n
	 */
	public ValidateSurvey(String n) {
		this.n = n;
	}
}
