/**
 * @author Joseph Yu, Joshua Huertas
 */
package enums;

public enum Ratings {
	noStars, oneStar, twoStars, threeStars, fourStars, fiveStars
}
