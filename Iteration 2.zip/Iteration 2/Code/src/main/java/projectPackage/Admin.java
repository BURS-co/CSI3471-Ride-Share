package projectPackage;

public class Admin extends User {
	
}
