package projectPackage;

public class Survey {

}
